clear all
clc
t=20; %time
n=5;  %grid size n x n
N=n*n;
H=38;
Current_Temperature=25;
A(n,n)=core_atp;
Temp_history=zeros(t,11,n,n);
Diff_history=zeros(t,11,n,n);
avg=zeros(t,n,n);
avg2=zeros(t,n,n);
R_ATk=zeros(t,n,n);
R_ABk=zeros(t,n,n);
theta=0.5;
Tth = 42;
Pro_Tth=39;
Availability=33;
TLA = 25;
thermal_resistance = 0.665;
Core_Task_Queue = zeros(N, 5);
Waiting_Queue = zeros(N, 4);
heat_data=zeros(n);
heat_data2=zeros(n);
heat_data3=zeros(n);
heat_data4=zeros(n);
heat_data5=zeros(n);
%colormap('hot(5)');
map = [ 0, 0, 1
        0, 1, 0
    	0, 1, 1
        1, 0, 1
        1, 1, 0
        1, 0, 0];
    map = [0.2, 0.1, 0.5
    0.1, 0.5, 0.8
    0.2, 0.7, 0.6
    0.8, 0.7, 0.3
    0.9, 1, 0];
map = flip(colormap('prism(5)'),1);

%total_threads = N;
%total_processes= randi(i, N
%possible_threads = [1 2 4 8];
%threads=threads_generation(N)
%total_applications =  numel(threads)
%initial_application_table=test_applications(N);
initial_application_table=test_app_no_thread(N,14,18);
application_table=initial_application_table;

hotspots =zeros(N, 1);
is_hotspot = zeros(n);
core_status = zeros(n);
is_available = zeros(n);
in_migration = zeros(n);
out_migration = zeros(n);
duration_counter_1=zeros(N, 1); %regular task
duration_counter_2=zeros(N, 1); %migrated task
task_completed_counter_1=zeros(N, 1);
task_completed_counter_2=zeros(N, 1);
for i = 1:N
Core_Task_Queue(N,1) = i;
end

Bal = 15;

no_of_hotspots = 0;
no_of_migrations = 0;
no_of_migrations_2 = 0;
%Cmn =[0.131 0.156 0.131 0.156 0.366 0.156 0.131 0.156 0.131];

show_heat_map = 1;
%colorbar;
for i=1:t
    Sum_chip_temp=0;
    i;
    for j=1:n
        for k=1:n
            
            A(j,k).grid_size=n;
            Core_Temperature = 25;
            ind=sub2ind([n n],j,k);
            A(j,k).core_loc_j=j;
            A(j,k).core_loc_k=k;
            
            [Cmn,x,y]=neighbor_temp(j, k, n, n);
            
            for a=1:numel(x)        %caclulate the core temperature using the normal task load
                ind_temp=sub2ind([n n],x(a),y(a));
                if  in_migration(ind_temp) == 0  %caclulate whether the neighbors have normal task or migrated task
                    ind_temp_2 = 2;
                else
                    ind_temp_2 = 5;
                end
                    Core_Temperature = Core_Temperature + application_table(ind_temp, ind_temp_2) * Cmn(a);  
            end
            
                
            A(j,k).current_temp=Core_Temperature;
                
            Temp_history(i,:,j,k)=(temp_history(A(j,k)))';
            temp=Temp_history(i,:,j,k);
            avg(i,j,k)=(sum(temp(1:10)))/10;
            
            R_ATk(i,j,k)=A(j,k).current_temp+avg(i,j,k)-H;
            R_ATk(i,j,k)=R_ATk(i,j,k)+theta*(A(j,k).current_temp-temp(10));
                
            Sum_chip_temp=Sum_chip_temp+A(j,k).current_temp;
            
           
            
            
            
            if R_ATk(i,j,k) > Pro_Tth
                hotspots(ind)=hotspots(ind) + 1 ;
                core_status(ind) = 7;
                is_hotspot(ind)=1;
            else
                is_hotspot(ind) = 0;
                if R_ATk(i,j,k) < Availability
                    core_status(ind) = 4;
                    is_available(ind) = 1;
                else
                    core_status(ind) = 1;
                    is_available(ind) = 0;
                end
            end
            
            %Execute tasks for those cores which are not hotspots 
            if is_hotspot(ind) == 0          %if the core is not a hotspot
                if in_migration(ind) == 0 %if the core does not have a migrated task
                    if application_table(ind, 3) > 0 %if the normal task is not already finished
                        duration_counter_1(ind) = duration_counter_1(ind)- 1; 
                        application_table(ind, 3) = application_table(ind, 3) - 1; %decrement duration of normal task by one
                        if application_table(ind, 3) == 0
                           application_table(ind, 2) = 0;
                        end
                    else
                        application_table(ind, 2) = 0;
                        application_table(ind, 3) = 0;
                    end
                else                                                           %if the core has a migrated task
                    if application_table(ind, 6) > 0 %if the migrtated task is not already finished
                        duration_counter_2(ind) = duration_counter_2(ind)- 1; 
                        application_table(ind, 6) = application_table(ind, 6) - 1; %decrement duration of migrated task by one
                        if application_table(ind, 6) == 0
                           application_table(ind, 5) = 0;
                           in_migration(ind) = 0;
                        end
                    else
                        application_table(ind, 5) = 0;
                        application_table(ind, 6) = 0;
                        in_migration(ind) = 0;
                    end
                end
            else                           %if the core is a hotspot
                if in_migration(ind) == 0
                    Waiting_Queue(ind, 1) = application_table(ind, 2); % copy the task into waiting queue
                    Waiting_Queue(ind, 2) = application_table(ind, 3);
                    application_table(ind, 2) = 0;
                    application_table(ind, 3) = 0;
                else
                    Waiting_Queue(ind, 3) = application_table(ind, 5); % copy the task into waiting queue
                    Waiting_Queue(ind, 4) = application_table(ind, 6);
                    application_table(ind, 5) = 0;
                    application_table(ind, 6) = 0;
                end
            end
            
    
            
            %Migration Stuff
            
%             in_migration=application_table(ind,5);
%             out_migration=application_table(ind,9);
%             duration_counter_1(ind) = application_table(ind, 3);
%             if  in_migration == 0 && out_migration == 0
%                 A(j,k).task_load=application_table(ind,2);
%                 duration_counter_1(ind) = duration_counter_1(ind)- 1;
%                 application_table(ind, 3) = application_table(ind, 3) - 1;
%                 if duration_counter_1(ind) == 0 
%                     task_completed_counter_1(ind) = task_completed_counter_1(ind) +1;
%                     application_table(ind,2) = randi([20,50]);
%                     application_table(ind,3) = randi(10);
%                 end
%             end
%             if in_migration == 1  && out_migration == 0
%                 A(j,k).task_load=application_table(ind,6);
%                 duration_counter_2(ind) = duration_counter_2(ind)- 1;
%                 application_table(ind,6) = application_table(ind,6) -1;
%                 if duration_counter_1(ind) == 0 
%                     in_migration = 0;
%                     task_completed_counter_2(ind) = task_completed_counter_2(ind) +1;
%                 end
%             end
            
            %Migration Stuff End
            
        end
    end
    
    
    
    
    %ABP
    Avg_chip_temp=Sum_chip_temp/N;
    for j=1:n
        for k=1:n
            A(j,k).current_chip_average=Avg_chip_temp;
            Diff_history(i,:,j,k)=(diff_history(A(j,k)))';
            temp=Diff_history(i,:,j,k);
            avg2(i,j,k)=(sum(temp(1:10)))/10;
            ek=A(j,k).current_temp - A(j,k).current_chip_average;
            R_ABk(i,j,k)=ek + avg2(i,j,k);
            R_ABk(i,j,k)=R_ABk(i,j,k)+theta*(ek-temp(10));
        end
    end
    
            [rc_RAB_max, max_RAB] = max(max(R_ABk(i,:,:)));
            rc_RAB_max = rc_RAB_max(1);
            max_RAB = max_RAB(1);
            [rc_RAB_min, min_RAB] = min(min(R_ABk(i,:,:)));
            rc_RAB_min = rc_RAB_min(1);
            min_RAB = min_RAB(1);
        
            counter_1 = application_table(3,:);
            counter_2 = application_table(6,:);
            M = sum(counter_1(:)>0);
            DyBal = 1 * N / M;
            %ABP End
    
    
    
    
    c1=Waiting_Queue(:,1);
    c2=Waiting_Queue(:,2);
    c3=Waiting_Queue(:,3);
    c4=Waiting_Queue(:,4);
    %[value, location] = max(A(:));
    
    %C1_temp=[c1;c3];
    %C2_temp=[c2;c4];
    ind_C1_temp_1=find(c1>0);
    ind_C1_temp_2=find(c3>0);
%     if isempty(ind_C1_temp_1)
%         if isempty(ind_C2_temp_2)
%             ind_C1=[];
%         else ind_C1=ind_C2_temp_2;
%         end
%     else 
%         if isempty(ind_C2_temp_2)
%             ind_C1=ind_C1_temp_1;
%         else
%             ind_C1=[ind_C2_temp_1 ind_C1_temp_2 +(2*N)]
%         end
%     end
            
    ind_C1=[ind_C1_temp_1; (ind_C1_temp_2 +(2*N))];
    
    ind_C2_temp_1=find(c2>0);
    ind_C2_temp_2=find(c4>0);
    ind_C2=[ind_C2_temp_1; (ind_C2_temp_2 +(2*N))];
    
    %ind_C2=find(C2_temp >0)
    available_cores = find(is_available > 0);
    min_C1_C2 = min(numel(ind_C1), numel(ind_C2));
    cores_limit = min([min_C1_C2 numel(available_cores)]);
    if cores_limit > 0
    for b=1:cores_limit
     
     application_table(available_cores(b), 5) = Waiting_Queue(ind_C1(b));
     application_table(available_cores(b), 6) = Waiting_Queue(ind_C2(b));
     in_migration(available_cores(b))=1;
     no_of_migrations = no_of_migrations + 1;
     Waiting_Queue(ind_C1(b)) = 0;
     Waiting_Queue(ind_C2(b)) = 0;
    end
    else
        if max_RAB > DyBal
            if in_migration(rc_RAB_min) == 0
                if in_migration(rc_RAB_max) == 0
                    application_table(rc_RAB_min, 3) = application_table(rc_RAB_max, 3);
                    application_table(rc_RAB_min, 2) = application_table(rc_RAB_max, 2);
                    no_of_migrations_2 = no_of_migrations_2 + 1;
                else
                    application_table(rc_RAB_min, 6) = application_table(rc_RAB_max, 6);
                    application_table(rc_RAB_min, 5) = application_table(rc_RAB_max, 5);
                    no_of_migrations_2 = no_of_migrations_2 + 1;
                end
            end
        end
    end
    
    
    %Heat Map
    if show_heat_map == 1
        mincolor=10;
        maxcolor=70;
        for j=1:n
            for k=1:n
            heat_data(j,k)=Temp_history(i,11,j,k);
            heat_data2(j,k)=R_ATk(i,j,k);
            heat_data3(j,k)=R_ABk(i,j,k);
            heat_data4(j,k)= core_status(j,k);
            if heat_data(j,k) > Tth
                if i>10
                    no_of_hotspots = no_of_hotspots + 1;
                end
                heat_data5(j,k) = 7;
            else
                heat_data5(j,k) = 0;
            end
            end
        end
        pause(0.01);
            s(1)=subplot(2,3,1);
            heatmap(heat_data, [], [], '%0.2f', 'Colormap', 'jet',...
            'Colorbar', true, 'ColorLevels', 7,  'MinColorValue', mincolor, 'MaxColorValue', maxcolor);
            s(2)=subplot(2,3,2);
            heatmap(heat_data2, [], [], '%0.2f', 'Colormap', 'jet',...
            'Colorbar', true, 'ColorLevels', 7,  'MinColorValue', mincolor, 'MaxColorValue', maxcolor);
            s(3)=subplot(2,3,3);
            heatmap(heat_data3, [], [], '%0.2f', 'Colormap', 'jet',...
            'Colorbar', true, 'ColorLevels', 7,  'MinColorValue', mincolor, 'MaxColorValue', maxcolor);
            s(4)=subplot(2,3,4);
            heatmap(heat_data4*10, [], [], [], 'Colormap', 'jet',...
            'Colorbar', true, 'ColorLevels', 7,  'MinColorValue', mincolor, 'MaxColorValue', maxcolor);
            s(5)=subplot(2,3,5);
            heatmap(heat_data5*10, [], [], [], 'Colormap', 'jet',...
            'Colorbar', true, 'ColorLevels', 7,  'MinColorValue', mincolor, 'MaxColorValue', maxcolor);
        
            title(s(1), ['Core Temperatures at t = ' num2str(i)]); 
            title(s(2), ['Predicted Temperature at t = ' num2str(i)]);  
            title(s(3), ['Error Predictor Values at t = ' num2str(i)]);            
            title(s(4), ['Red = Hotspots, Green = Avaliable, Mig. Count =  ' num2str(no_of_migrations), ', at t = ' num2str(i)]);
            title(s(5), ['Hotspots on Actual Core at t = ' num2str(i)]);
    end
    %Heat Map End
end
