function [Cmn,n_x, n_y] = neighbor_temp(x, y, M, N)
%UNTITLED8 Summary of this function goes here
%   Detailed explanation goes here
Cmn =[0.131 0.156 0.131 0.156 0.366 0.156 0.131 0.156 0.131];
n1_x = x - 1;
n2_x = x - 1;
n3_x = x - 1;
n4_x=  x;
n5_x=  x;
n6_x=  x;
n7_x = x + 1;
n8_x = x + 1;
n9_x = x + 1;

n1_y = y - 1;
n2_y = y ;
n3_y = y + 1;
n4_y=  y - 1;
n5_y=  y;
n6_y=  y + 1;
n7_y = y - 1;
n8_y = y ;
n9_y = y + 1;



 n_x = [n1_x n2_x n3_x n4_x n5_x n6_x n7_x n8_x n9_x];
 n_y = [n1_y n2_y n3_y n4_y n5_y n6_y n7_y n8_y n9_y];
 
 b=find(n_x > 0 & n_x < M+1);
 n_x=n_x(b);
 Cmn =Cmn(b);
 n_y=n_y(b);
 b=find(n_y > 0 & n_y < N+1);
 n_y=n_y(b);
 n_x=n_x(b);
 Cmn =Cmn(b);
 
 
 
 
end
