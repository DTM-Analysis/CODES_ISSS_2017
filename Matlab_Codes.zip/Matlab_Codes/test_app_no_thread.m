function application_table =test_app_no_thread(N,p1, p2)
%threads=threads_generation(N);
total_applications =  N;
application_table =zeros(N, 9);
k=1;
for i=1:total_applications
    power=randi([p1, p2]);
    duration=randi([20 60]);
    %for j=1:threads(i);
    application_table(i,1) = i;
    application_table(i,2)= power;
    application_table(i,3)= duration;
    %k=k+1;
    %end;
application_table(i,4)=1;
end
end