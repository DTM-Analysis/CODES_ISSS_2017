classdef core_atp
    %core_atp atp for cores
    %   
    
    properties
        grid_size;
        current_temp;
        core_loc_j;
        core_loc_k;
        current_chip_average;
        task_load;
        process_id;
        thread_id;
        master_thread;
        migration_from;
    end
    
    methods
        function temp_his = temp_history(obj)
            %temp_history stores the history for last 10 temperature values
            %
            persistent sum_temp;
            if isempty(sum_temp)
                sum_temp=zeros(11,obj.grid_size,obj.grid_size);
                sum_temp(11,obj.core_loc_j,obj.core_loc_k)=25;
            end
            sum_temp(:,obj.core_loc_j,obj.core_loc_k)=circshift(sum_temp(:,obj.core_loc_j,obj.core_loc_k),-1,1);
            sum_temp(11,obj.core_loc_j,obj.core_loc_k)= obj.current_temp; %0.665 * core_power(obj) + sum_temp(11,obj.core_loc_j,obj.core_loc_k); %sum_temp(11,obj.core_loc_j,obj.core_loc_k);
            %obj.current_temp=0.665 * core_power(obj) + 25% sum_temp(11,obj.core_loc_j,obj.core_loc_k)
            temp_his=sum_temp(:,obj.core_loc_j,obj.core_loc_k);
        end
        function avg=temp_avg(obj)
            temp=temp_history(obj);
            avg=(sum(temp(1:10)))/10;
        end
        function diff_his = diff_history(obj)
            persistent diff_temp;
            if isempty(diff_temp)
                diff_temp=zeros(11,obj.grid_size,obj.grid_size);
            end
            diff_temp(:,obj.core_loc_j,obj.core_loc_k)=circshift(diff_temp(:,obj.core_loc_j,obj.core_loc_k),-1,1);
            temp123=obj.current_temp;
            diff_temp(11,obj.core_loc_j,obj.core_loc_k)=obj.current_temp-obj.current_chip_average;
            diff_his=diff_temp(:,obj.core_loc_j,obj.core_loc_k);
        end
        function avg=diff_avg(obj)
            temp=diff_history(obj);
            avg=(sum(temp(1:10)))/10;
        end
        function queue=task_queue(obj)
        persistent Core_Task_Queue;
            if isempty(Core_Task_Queue)
                Core_Task_Queue=zeros(obj.grid_size*obj.grid_size, 7);
            end
            core_id = sub2ind([obj.grid_size obj.grid_size], obj.core_loc_j,obj.core_loc_k);
            Core_Task_Queue(core_id) = core_id;
            Core_Task_Queue(core_id, 2) = obj.process_id;
            Core_Task_Queue(core_id, 3) = obj.thread_id;
            Core_Task_Queue(core_id, 4) = obj.task_load;
            Core_Task_Queue(core_id, 5) = obj.thread_id;
            Core_Task_Queue(core_id, 6) = obj.thread_id;
        end
%          function executetask= execute_task(obj)
%          if obj.migration_from = 1 
%          Core_Task_Queue(core_id, 2) = obj.process_id;
%             Core_Task_Queue(core_id, 3) = obj.thread_id;
%             Core_Task_Queue(core_id, 4) = obj.task_load;
%             Core_Task_Queue(core_id, 5) = obj.thread_id;
%             Core_Task_Queue(core_id, 6) = obj.thread_id;
%          else
%             Core_Task_Queue(core_id, 2) = obj.process_id;
%             Core_Task_Queue(core_id, 3) = obj.thread_id;
%             Core_Task_Queue(core_id, 4) = obj.task_load-1;
%             Core_Task_Queue(core_id, 5) = obj.thread_id;
%             Core_Task_Queue(core_id, 6) = obj.thread_id;
%          end 
%          end
        
        function power = core_power(obj)
            power = obj.task_load; 
        end
        
        function  temperature = core_temperature(obj)
            temperature = 0.665 * core_power(obj) + 25;
            end
        
%         function obj = core_atp(F)
%             if nargin ~= 0
%                 m = size(F,1);
%                 n = size(F,2);
%                 obj(m,n) = core_atp;
%                 for i = 1:m
%                     for j = 1:n
%                         obj(i,j).current_temp = F(i,j);
%                     end
%                 end
%             end
%         end
    end
end

